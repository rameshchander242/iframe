<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Series;
use App\Models\Item;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Traits\FileUploadTrait;
use DataTables;

class ItemController extends Controller
{
    use FileUploadTrait;
    public $nav = 'item';

    public function __construct() {
        $this->middleware('auth:admin');
        View::share('nav', $this->nav);
    }
    
    public function index() {
        return view('admin.pages.'.$this->nav.'.index');
    }

    public function list_ajax() {
        $items = Item::with('category');

        return DataTables::of($items)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
                        $btn = edit_button( route('item.edit', $row->id) ) . '&nbsp; ' .
                        view_button( route('item.show', $row->id) ) . '&nbsp; ' .
                        delete_button( route('item.destroy', $row->id) );
                        return $btn;
                    })
                    ->editColumn('category', function ($row) {
                        return isset($row->category) ? $row->category->name : '--';
                    })
                    ->editColumn('status', function ($row) {
                        return '<div class="text-center">' . view_status($row->status) . '</div>';
                    })
                    ->editColumn('image', function ($row) {
                        return ($row->image != null) ? '<img height="50px" src="' . asset( upload_url($this->nav) . $row->image ) . '">' : 'N/A';
                    })
                    ->rawColumns(['action', 'image', 'status'])
                    ->make(true);
    }

    public function create() {
        $categories = Category::where('status', '1')->get()->pluck('name', 'id');

        return view('admin.pages.'.$this->nav.'.create', compact('categories'));
    }

    public function store(request $request) {
        $request->all();
        $request = $this->saveFiles($request, $this->nav);
        $item = Item::create($request->all());
        
        return redirect()->route('item.index')->withSuccess("Item Create successfully");
    }

    public function edit($id) {
        $item = Item::find($id);
        $categories = Category::where('status', '1')->get()->pluck('name', 'id');
        $brands = Brand::where(['status'=>'1', 'category_id'=>$item->category_id])->get()->pluck('name', 'id');

        return view('admin.pages.'.$this->nav.'.edit', $item, compact('categories','brands'));
    }

    public function update(request $request, $id) {
        $item = Item::findOrFail($id);
        $request = $this->saveFiles($request, $this->nav);
        $item->update($request->all());

        return redirect()->route('item.index')->withSuccess('Item Update successfully');
    }

    public function show($id) {
        $item = Item::find($id);

        return view('admin.pages.'.$this->nav.'.show', $item);
    }

    public function destroy($id) {
        $item = Item::findOrFail($id);
        $item->delete();

        return redirect()->route('item.index')->withSuccess('Item Delete successfully');
    }
}
