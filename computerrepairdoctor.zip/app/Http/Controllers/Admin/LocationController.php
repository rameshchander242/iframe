<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Location;
use Illuminate\Support\Facades\View;
use DataTables;

class LocationController extends Controller
{
    public $nav = 'location';

    public function __construct() {
        $this->middleware('auth:admin');
        View::share('nav', $this->nav);
    }
    
    public function index() {
        return view('admin.pages.'.$this->nav.'.index');
    }

    public function list_ajax() {
        $locations = Location::with('user');

        return DataTables::of($locations)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
                        $btn = edit_button( route('location.edit', $row->id) ) . '&nbsp; ' .
                        view_button( route('location.show', $row->id) ) . '&nbsp; ' .
                        delete_button( route('location.destroy', $row->id) );
                        return $btn;
                    })
                    ->editColumn('user', function ($row) {
                        return isset($row->user) ? $row->user->name : '--';
                    })
                    ->editColumn('status', function ($row) {
                        return '<div class="text-center">' . view_status($row->status) . '</div>';
                    })
                    ->editColumn('image', function ($row) {
                        return ($row->image != null) ? '<img height="50px" src="' . asset( upload_url($this->nav) . $row->image ) . '">' : 'N/A';
                    })
                    ->rawColumns(['action', 'image', 'status'])
                    ->make(true);
    }

    public function create() {
        $users = User::where('status', '1')->get()->pluck('name', 'id');
        return view('admin.pages.'.$this->nav.'.create', compact( 'users'));
    }

    public function store(request $request) {
        $request->all();
        $location = Location::create($request->all());

        return redirect()->route('location.index')->withSuccess("Location Create successfully");
    }

    public function edit($id) {
        $location = Location::find($id);
        $users = User::where('status', '1')->get()->pluck('name', 'id');

        return view('admin.pages.'.$this->nav.'.edit', $location, compact('users'));
    }

    public function update(request $request, $id) {
        $location = Location::findOrFail($id);
        $location->update($request->all());

        return redirect()->route('location.index')->withSuccess('Location Update successfully');
    }

    public function show($id) {
        $location = Location::with('user')->find($id);

        return view('admin.pages.'.$this->nav.'.show', $location);
    }

    public function destroy($id) {
        $location = Location::findOrFail($id);
        $location->delete();
        
        return redirect()->route('location.index')->withSuccess('Location Delete successfully');
    }
}
