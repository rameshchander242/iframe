<div class="col-md-12 pl-0">
    <div class="col-md-5 pl-0">
        <h3 class = "mt-0">Security</h3>
    </div>
</div>
<form action="{{ route('security') }}" method="post" id = "update-security">
                  {{ csrf_field() }}
                <input type="hidden" name = "id" value = "{{ $user->id }}"> 
                <div class="form-group">
                  <label>Old Password</label>
                  <input type="password" class="form-control" placeholder="Old Password" name = "old_password" required>
                        <span class="error-container err" id = "old_password"></span>
                </div>
                <div class="form-group">
                  <label>New Password</label>
                  <input type="password" class="form-control" placeholder="New Password" name = "password" required>
                        <span class="error-container err" id = "password"></span>
                </div>
                <div class="form-group">
                  <label>Confirm Password</label>
                  <input type="password" class="form-control" placeholder="Confirm Password" name = "password_confirmation" required>
                        <span class="error-container err" id = "password_confirmation"></span>
                </div>
                <div class="form-group">
                      
                        <button type="submit" class="btn btn-danger">Update</button>
                        <span id = "success"></span>
                </div>
</form>