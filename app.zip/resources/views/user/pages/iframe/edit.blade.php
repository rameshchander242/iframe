@extends('user.layouts.app')
@section('title','Edit')

@section('content')
{!! Form::open(['method' => 'PUT', 'route' => ['user.iframe.update', $iframe['id']], 'files' => true,]) !!}
    <div class="form-group">
      <div class="row">
        <div class="col-sm-6">{!!Form::label('name', 'Name')!!}</div>
        <div class="col-sm-6">{{ $iframe['name'] }}</div>
        <div class="col-sm-6">{!!Form::label('name', 'Locations')!!}</div>
        <div class="col-sm-6"> 
            @foreach ($iframe['user']['locations'] as $location)
            {{$location['store_name'] }}
            @endforeach
        </div>
      </div>
    </div>

    <div class="card iframe-table">
        <div class="card-body table-responsive p-1">
            <ul class="nav nav-tabs">
                @foreach ($iframe['categories'] as $key=>$category)
                <li class="nav-item">
                    <a class="nav-link {{$key==0 ? 'active': ''}}" data-toggle="tab" href="#category{{$category['id']}}">{{$category['name']}}</a>
                </li>
                @endforeach
            </ul>
            <div class="tab-content">
                @foreach ($iframe['categories'] as $key=>$category)
                <?php $b = 0; ?>
                <div id="category{{$category['id']}}" class="col-12 tab-pane {{$key==0 ? 'active': ''}}"><br>
                  <h3>{{$category['name']}}</h3>
                  <table class="table">
                    @foreach ($category['brands'] as $brand)
                        <?php $b++; ?>
                        <tr>
                            <th>{{$brand['name']}}</th>
                            @foreach ($category['services'] as $service)
                                <th>{{$service['name']}}</th>
                            @endforeach
                        </tr>
                        @foreach ($brand['items'] as $item)
                            <tr>
                                <td class="text-nowrap">{{$item['name']}}</td>
                                @foreach ($iframe['categories'][$key]['services'] as $service)
                                <td>
                                    <?php $item_service = json_decode($iframe['item_service'], true); ?>
                                    <input class="form-control text-center input-sm" type="text" name="item_service[{{$category['id']}}][{{$item['id']}}][{{$service['id']}}]" value="{{$item_service[$category['id']][$item['id']][$service['id']] ?? ''}}">
                                </td>
                                @endforeach
                            </tr>
                        @endforeach
                    @endforeach
                    @if ($b == 0)
                    <tr>
                        <th> -- </th>
                        @foreach ($category['services'] as $service)
                            <th>{{$service['name']}}</th>
                        @endforeach
                    </tr>
                    @foreach ($category['items'] as $item)
                        <tr>
                            <td class="text-nowrap">{{$item['name']}}</td>
                            @foreach ($iframe['categories'][$key]['services'] as $service)
                            <td>
                                <?php $item_service = json_decode($iframe['item_service'], true); ?>
                                <input class="form-control text-center input-sm" type="text" name="item_service[{{$category['id']}}][{{$item['id']}}][{{$service['id']}}]" value="{{$item_service[$category['id']][$item['id']][$service['id']] ?? ''}}">
                            </td>
                            @endforeach
                        </tr>
                    @endforeach
                    @endif
                    
                  </table>
                </div>
                @endforeach
            </div>
            {{-- <table class="table">
                @foreach ($iframe['categories'] as $key=>$category)
                    <tr><th class="h2 text-danger" colspan="10">{{$category['name']}}</th></tr>
                    <tr>
                        <th>Name</th>
                    @foreach ($category['services'] as $service)
                        <th>{{$service['name']}}</th>
                    @endforeach
                    </tr>

                    @foreach ($category['brands'] as $brand)
                        <tr><th class="h4 text-info" colspan="10">{{$brand['name']}}</th></tr>
                        @foreach ($brand['items'] as $item)
                            <tr>
                                <td>{{$item['name']}}</td>
                                @foreach ($iframe['categories'][$key]['services'] as $service)
                                <td>
                                    <?php $item_service = json_decode($iframe['item_service'], true); ?>
                                    <input class="form-control text-center input-sm" type="text" name="item_service[{{$category['id']}}][{{$item['id']}}][{{$service['id']}}]" value="{{$item_service[$category['id']][$item['id']][$service['id']] ?? ''}}">
                                </td>
                                @endforeach
                            </tr>
                        @endforeach
                    @endforeach

                    <tr><th class="h4 text-warning" colspan="10">No Brands</th></tr>
                    @foreach ($category['items'] as $item)
                        <tr>
                            <td>{{$item['name']}}</td>
                            @foreach ($iframe['categories'][$key]['services'] as $service)
                            <td>
                                <?php $item_service = json_decode($iframe['item_service'], true); ?>
                                <input class="form-control text-center input-sm" type="text" name="item_service[{{$category['id']}}][{{$item['id']}}][{{$service['id']}}]" value="{{$item_service[$category['id']][$item['id']][$service['id']] ?? ''}}">
                            </td>
                            @endforeach
                        </tr>
                    @endforeach


                @endforeach
            </table> --}}

        </div>

    </div>
    <hr>
    <div class="form-group text-center">
        {!! Form::submit('Save', ['class' => 'btn btn-primary btn-lg']) !!}
        &nbsp; &nbsp;
        {{ back_button(route('user.iframe.index')) }}
    </div>
{!! Form::close() !!}
@endsection

@push('custom_scripts')
<script type="text/javascript">
$(document).ready(function() {
    $('a[data-widget="pushmenu"]').click()

});
</script>
@endpush