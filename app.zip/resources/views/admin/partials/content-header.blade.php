<div class="content-header mb-3 navbar-white">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">@yield('title')</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <?php $link = "" ?>
          @for($i = 1; $i <= count(Request::segments()); $i++)
            @if($i < count(Request::segments()) & $i > 0)
            <?php $link .= "/" . Request::segment($i); ?>
            <li class="breadcrumb-item"><a href="<?= $link ?>">{{ ucwords(str_replace('-',' ', str_replace('admin','Dashboard',Request::segment($i)) ))}}</a></li>
            @else 
            <li class="breadcrumb-item">{{ucwords(str_replace('-',' ',Request::segment($i)))}}</li>
            @endif
          @endfor
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>