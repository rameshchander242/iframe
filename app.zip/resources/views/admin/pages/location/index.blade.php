@extends('admin.layouts.app')
@section('title', 'Locations')

@push('custom_styles')
<link href="{{ asset('css/admin/datatables.min.css') }}" rel="stylesheet">
@endpush

@section('content')
    <div class="text-right mb-2">
        {!! edit_button( route('location.create') ,'fa-plus', 'Add New' ) !!}
    </div>

    <table id="yajra_datatable" class="table table-bordered table-hover dataTable dtr-inline">
        <thead>
        <tr>
            <th>Store Name</th>
            <th>City</th>
            <th>Address</th>
            <th>Client</th>
            <th>Status</th>
            <th>Action</th>
        </tr> 
        </thead>
    </table>

@endsection

@push('custom_scripts')
<script src="{{ asset('js/admin/jquery.dataTables.min.js') }}"></script>
<script type="text/javascript">
    function initDataTable() {
        var YajraDataTable = $('#yajra_datatable').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": "{{ route('location.listajax') }}",
            "columns":[
                {
                    "data": "store_name",
                    "name": "store_name"
                },
                {
                    "data": "city",
                    "name": "city"
                },
                {
                    "data": "address_1",
                    "name": "address_1"
                },
                {
                    "data": "user",
                    "name": "user"
                },
                {
                    "data": "status",
                    "name": "status"
                },
                {
                    data: 'action', 
                    name: 'action', 
                    orderable: true, 
                    searchable: true
                },
            ],
            'order': [0, 'asc'], // Order on init. Number is the column, starting at 0
        });
        return YajraDataTable;
    }

    $(document).ready(function() {
        var YajraDataTable = initDataTable();
    });
</script>
@endpush