<div class="col-md-12 pl-0">
  <div class="col-md-5 pl-0">
    <h3 class = "mt-0">Basic Details</h3>
  </div>
</div>
<form action="{{ route('admin-basic-profile') }}" method="post">
  {{ csrf_field() }}
  <input type="hidden" name = "id" value = "{{ $user->id }}">
  <div class="form-group">
    <label>First Name</label>
    <input type="text" class="form-control" placeholder="Name" value="{{  $user->name }}" name = "name" required>
    @if ($errors->has('name'))
    <span class = "err">{{ $errors->first('name') }}</span>
    @endif
  </div>
  
  <div class="form-group">
    <label>Email</label>
    <input type="email" class="form-control" placeholder="Email" value="{{  $user->email }}" disabled="true" name = "email" required>
    @if ($errors->has('email'))
    <span class = "err">{{ $errors->first('email') }}</span>
    @endif
  </div>
  <div class="form-group">
    <label>Contact</label>
    <input type="tel" class="form-control validate_number" maxlength="10" placeholder="Contact" value="{{  $user->contact }}" name = "contact" required>
    @if ($errors->has('contact'))
    <span class = "err">{{ $errors->first('contact') }}</span>
    @endif
  </div>
  
  <div class="form-group">
    <button type="submit" class="btn btn-danger">Update</button>
  </div>
</form>