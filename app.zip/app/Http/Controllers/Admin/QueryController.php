<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Widget_Quote;
use Illuminate\Support\Facades\View;
use App\Http\Controllers\Traits\FileUploadTrait;
use DataTables;

class QueryController extends Controller
{
    use FileUploadTrait;
    public $nav = 'query';

    public function __construct() {
        $this->middleware('auth:admin');
        View::share('nav', $this->nav);
    }
    
    public function index() {
        // $queries = Widget_Quote::select('*')
        // ->with('user', 'category', 'brand', 'series', 'item', 'service', 'location')
        // ->get()->toArray();
        // echo "<pre>"; print_r($queries); exit;


        return view('admin.pages.'.$this->nav.'.index');
    }

    public function list_ajax() {
        $queries = Widget_Quote::select('*')
        ->with('user', 'category', 'brand', 'series', 'item', 'service', 'location');

        return DataTables::of($queries)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
                        $btn = view_button( route('admin.queries.show', $row->id) );
                        return $btn;
                    })
                    ->addColumn('client', function ($row) {
                        return $row->user->name;
                    })
                    ->editColumn('category', function ($row) {
                        return $row->category->name;
                    })
                    ->editColumn('item', function ($row) {
                        return $row->item->name;
                    })
                    ->editColumn('service', function ($row) {
                        return $row->service->name;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
    }

    public function create() {
        return view('admin.pages.'.$this->nav.'.create');
    }

    public function store(request $request) {
        $request->all();
        $request = $this->saveFiles($request, $this->nav);
        $query = Widget_Quote::create($request->all());
        
        return redirect()->route('query.index')->withSuccess("Widget_Quote Create successfully");
    }

    public function edit($id) {
        $query = Widget_Quote::find($id);

        return view('admin.pages.'.$this->nav.'.edit', $query);
    }

    public function update(request $request, $id) {
        $query = Widget_Quote::findOrFail($id);
        $request = $this->saveFiles($request, $this->nav);
        $query->update($request->all());

        return redirect()->route('query.index')->withSuccess('Widget_Quote Update successfully');
    }

    public function show($id) {
        $query = Widget_Quote::find($id);

        return view('admin.pages.'.$this->nav.'.show', $query);
    }

    public function destroy($id) {
        $query = Widget_Quote::findOrFail($id);
        $query->delete();

        return redirect()->route('query.index')->withSuccess('Widget_Quote Delete successfully');
    }
}
