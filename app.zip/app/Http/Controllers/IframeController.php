<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Iframe;
use App\Models\Widget_Quote;

class IframeController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function iframe($id) {
        $iframe = Iframe::findOrFail($id);
        return view('iframe', $iframe);
    }

    public function submit_widget(Request $request) {
        $data = $request->all();
        $data['ip_address'] = $_SERVER['REMOTE_ADDR'];
        // echo "<pre>"; print_r($data); exit;
        $widget = Widget_Quote::create($data);
        return response()->json(['success' => true, 'data'   => 'Successfully Submit']); 
    }

}
