<?php
if (!function_exists('upload_path')) {
    function upload_path($path) {
        $uploadDir = storage_path('app/public/uploads');
        return $uploadDir . '/' . $path;
    }
}

if (!function_exists('upload_url')) {
    function upload_url($path) {
        return 'storage/uploads/' . $path . '/';
    }
}

if (!function_exists('back_button')) {
    function back_button($url, $button="Back") {
        $title = empty($button) ? 'Back' : $button;
        $button = Form::button($button, ['class' => 'btn btn-dark btn-lg', 'onclick' => 'window.location="'.$url.'"']);
        return $button;
    }
}

if (!function_exists('delete_button')) {
    function delete_button($url, $button="") {
        $title = empty($button) ? 'Delete' : $button;
        $button = '<a href="javascript:void(0)" class="delete-action btn btn-danger btn-sm" title="' . $title . '">
            <i class="fa fa-trash"></i> ' . $button . '</a>
        <form method="POST" action="' . $url . '">' . 
            csrf_field() . 
            method_field("DELETE") . '
        </form>';
        return $button;
    }
}

if (! function_exists('edit_button') ) {
    function edit_button ($url, $icon="fa-edit", $button="") {
        $title = empty($button) ? 'Edit' : $button;
        return '<a href="' . $url . '" class="edit btn btn-primary btn-sm" title="' . $title . '">
            <i class="fa ' . $icon . '"></i>' . $button . '</a>';
    }
}

if (! function_exists('view_button') ) {
    function view_button ($url, $icon="fa-eye", $button="") {
        $title = empty($button) ? 'View' : $button;
        return '<a href="' . $url . '" class="viwe btn btn-success btn-sm" title="' . $title . '">
            <i class="fa ' . $icon . '"></i>' . $button . '</a>';
    }
}

if (! function_exists('view_status') ) {
    function view_status ($status) {
        return $status=='1' ? '<i class="fa fa-check-circle text-success"></i>' : '<i class="fa fa-times-circle text-danger"></i>';
    }
}

